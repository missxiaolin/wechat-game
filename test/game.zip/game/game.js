import { Main } from './Main.js'

new Main()